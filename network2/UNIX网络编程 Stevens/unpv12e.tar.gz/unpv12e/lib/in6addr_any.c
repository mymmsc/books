#include	"unp.h"

#ifdef	IPV6
const struct in6_addr in6addr_any;
#endif

#include	"unpipc.h"

#define	MQ_KEY1	1234L
#define	MQ_KEY2	2345L
